import personajes.*;

import javax.swing.text.PlainDocument;
import java.sql.SQLSyntaxErrorException;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int opc = 0;

        List<Personaje> personajes = new ArrayList<>();
        Map<String, Personaje> registro = new HashMap<>();

        do {
            System.out.println("====================================");
            System.out.println("        ESFOT RPG - Java POO");
            System.out.println("====================================");
            System.out.println("1. Crear Guerreo");
            System.out.println("2. Crear Mago");
            System.out.println("3. Crear Arquero");
            System.out.println("4. Crear Paladín");
            System.out.println("5. Mostrar personajes");
            System.out.println("6. Buscar personaje por nombre");
            System.out.println("7. Atacar a otro personaje");
            System.out.println("8. Utilizar habilidad especial");
            System.out.println("9. Simular combate por turnos");
            System.out.println("10. Mostrar personajes vivos");
            System.out.println("11. Salir");
            System.out.print("Seleccione una opcion: ");
            opc = sc.nextInt();
            sc.nextLine();

            switch (opc) {
                case 1:{
                    System.out.print("Ingrese el nombre del personaje: ");
                    String nombreGuerrero = sc.nextLine();

                    if (registro.containsKey(nombreGuerrero)){
                        System.out.println("[ERROR]: Ya existe un personaje con ese nombre!");
                    } else {
                        Guerrero nuevoGuerrero = new Guerrero(18, 12, 1, nombreGuerrero, 120, 120, 20);

                        personajes.add(nuevoGuerrero);
                        registro.put(nuevoGuerrero.getNombre(), nuevoGuerrero);

                        System.out.println("Guerrero creado!");
                        nuevoGuerrero.mostrarInfo();
                    }
                    break;
                }
                case 2:{
                    System.out.print("Ingrese el nombre del personaje: ");
                    String nombreMago = sc.nextLine();

                    if (registro.containsKey(nombreMago)){
                        System.out.println("[ERROR]: Ya existe un personaje con ese nombre!");
                    } else {
                        Mago nuevoMago = new Mago(10, 5, 1, nombreMago, 80, 80, 100);

                        personajes.add(nuevoMago);
                        registro.put(nuevoMago.getNombre(), nuevoMago);

                        System.out.println("Mago creado!");
                        nuevoMago.mostrarInfo();
                    }
                    break;
                }
                case 3:{
                    System.out.print("Ingrese el nombre del personaje: ");
                    String nombreArquero = sc.nextLine();

                    if (registro.containsKey(nombreArquero)){
                        System.out.println("[ERROR]: Ya existe un personaje con ese nombre!");
                    } else {
                        Arquero nuevoArquero = new Arquero(16, 8, 1, nombreArquero, 95, 95, 15);

                        personajes.add(nuevoArquero);
                        registro.put(nuevoArquero.getNombre(), nuevoArquero);

                        System.out.println("Arquero creado!");
                        nuevoArquero.mostrarInfo();
                    }
                    break;
                }
                case 4:{
                    System.out.print("Ingrese el nombre del personaje: ");
                    String nombrePaladín = sc.nextLine();

                    if (registro.containsKey(nombrePaladín)){
                        System.out.println("[ERROR]: Ya existe un personaje con ese nombre!");
                    } else {
                        Paladin nuevoPaladin = new Paladin(12, 15, 1, nombrePaladín, 140, 140, 20, 50);

                        personajes.add(nuevoPaladin);
                        registro.put(nuevoPaladin.getNombre(), nuevoPaladin);

                        System.out.println("Paladín creado!");
                        nuevoPaladin.mostrarInfo();
                    }
                    break;
                }
                case 5:{
                    System.out.println("--------------------");
                    System.out.println("Lista de personajes");
                    for (Personaje personaje: personajes){
                        personaje.mostrarInfo();
                    }
                    break;
                }
                case 6:{
                    System.out.print("Ingrese el nombre del personaje: ");
                    String nombre = sc.nextLine();

                    if(registro.containsKey(nombre)){
                        Personaje encontrado = registro.get(nombre);
                        System.out.println("--------------------");
                        System.out.println("Personje encontrado!");
                        encontrado.mostrarInfo();
                    } else {
                        System.out.println("[ERROR]: Personaje no encontrado!");
                    }
                    break;
                }
                case 7:{
                    System.out.println("--------------------");
                    System.out.print("Ingrese el nombre del aliado: ");
                    String nombreAliado = sc.nextLine();
                    System.out.print("Ingrese el nombre del enemigo: ");
                    String nombreEnemigo = sc.nextLine();

                    Personaje aliado = registro.get(nombreAliado);
                    Personaje enemigo = registro.get(nombreEnemigo);

                    if (aliado != null && enemigo != null) {
                        if (aliado == enemigo) {
                            System.out.println("No se puede atacarse el mismo personaje");
                        } else {
                            int danio = aliado.getAtaque();
                            enemigo.recibirDanio(danio);
                        }
                    } else if (aliado != null){
                        System.out.println("[ERROR]: No existe el enemigo");
                    } else {
                        System.out.println("[ERROR]: No existe el aliado");
                    }
                    break;
                }
                case 8:{
                    System.out.print("Nombre del aliado que usará su habilidad: ");
                    String nombreAliado = sc.nextLine();
                    System.out.print("Nombre del enemigo: ");
                    String nombreEnemigo = sc.nextLine();

                    Personaje enemigo = registro.get(nombreEnemigo);
                    Personaje aliado = registro.get(nombreAliado);

                    if(aliado != null && enemigo != null){
                        if (aliado instanceof Mago){
                            Mago mago = (Mago) aliado;
                            mago.lanzarHechizo(enemigo);
                        } else if (aliado instanceof Arquero) {
                            Arquero arquero = (Arquero) aliado;
                            arquero.dispararFlecha(enemigo);
                        } else if (aliado instanceof Paladin) {
                            Paladin paladin = (Paladin) aliado;
                            System.out.println("Que habilidad desea usar?");
                            System.out.println("1. Activar escudo");
                            System.out.print("2. Curar aliado\nSleccione una opcion (1 o 2): ");
                            int habilidad = sc.nextInt();
                            sc.nextLine();

                            switch (habilidad){
                                case 1:{
                                    paladin.activarEscudo();
                                    break;
                                }
                                case 2:{
                                    System.out.print("Ingrese nombre del aliado a curar: ");
                                    String aliadoCurar = sc.nextLine();
                                    if(registro.containsKey(aliadoCurar)){
                                        Personaje aliadoDebil = registro.get(aliadoCurar);
                                        paladin.curar(aliadoDebil);
                                    }else {
                                        System.out.println("Aliado no encontrado");
                                    }
                                    break;
                                }
                                default:{
                                    System.out.println("[ERROR]: Habilidad no valida!");
                                    break;
                                }
                            }
                        } else {
                            Guerrero guerrero = (Guerrero) aliado;
                            guerrero.atacar(enemigo, 25);
                        }
                    } else if (aliado != null){
                        System.out.print("[ERROR]: No existe enemigo");
                    } else {
                        System.out.print("[ERROR]: No existe aliado");
                    }
                    break;
                }
                case 9:{
                    System.out.println("--------------------");
                    System.out.print("Ingrese el nombre del aliado: ");
                    String nombreAliado = sc.nextLine();
                    System.out.print("Ingrese el nombre del enemigo: ");
                    String nombreEnemigo = sc.nextLine();

                    Personaje aliado = registro.get(nombreAliado);
                    Personaje enemigo = registro.get(nombreEnemigo);

                    if (aliado != null && enemigo != null){

                        if (aliado == enemigo){
                            System.out.println("[ERROR]: Un personaje no se puece atacar asi mismo!");
                            break;
                        }

                        if (aliado.estaVivo() && enemigo.estaVivo()){
                            String claseAliado;
                            String claseEnemigo;
                            if (aliado instanceof Mago){
                                claseAliado = "Mago";
                            } else if (aliado instanceof Arquero){
                                claseAliado = "Arquero";
                            } else if (aliado instanceof Paladin){
                                claseAliado = "Paladín";
                            } else {
                                claseAliado ="Guerrero";
                            }
                            if (enemigo instanceof Mago){
                                claseEnemigo = "Mago";
                            } else if (enemigo instanceof Arquero){
                                claseEnemigo = "Arquero";
                            } else if (enemigo instanceof Paladin){
                                claseEnemigo= "Paladín";
                            } else {
                                claseEnemigo="Guerrero";
                            }
                            System.out.println("===== COMBATE RPG =====");
                            int turno = 1;
                            do{
                                System.out.println(aliado.getNombre()+" ("+claseAliado+") vs "+enemigo.getNombre()+" ("+claseEnemigo+")");
                                System.out.print("Turno "+turno+": ");
                                aliado.atacar(enemigo);
                                int danio = aliado.getAtaque();
                                enemigo.recibirDanio(danio);
                                if (!enemigo.estaVivo()){
                                    break;
                                }
                                System.out.println("--------------------");
                                turno++;
                                System.out.print("Turno "+turno+": ");
                                enemigo.atacar(aliado);
                                danio = enemigo.getAtaque();
                                aliado.recibirDanio(danio);
                                System.out.println("--------------------");
                                turno++;
                            } while (aliado.estaVivo() && enemigo.estaVivo());
                            System.out.println("---");
                            if (aliado.estaVivo()){
                                System.out.println("Ganador: "+aliado.getNombre());
                            } else {
                                System.out.println("Ganador: "+enemigo.getNombre());
                            }
                        } else if (aliado.estaVivo()){
                            System.out.println("[ERROR]: No se puede iniciar un combato con un enemigo derrotado");
                        } else {
                            System.out.println("[ERROR]: No se puede iniciar un combato con un aliado derrotado");
                        }
                    } else if (aliado != null) {
                        System.out.println("[ERROR]: No existe el enemigo!");
                    } else {
                        System.out.println("[ERROR]: No existe el alaido!");
                    }
                    break;
                }
                case 10:{
                    System.out.println("--------------------\nPersonajes vivos");
                    int id =1;
                    for (Personaje p: personajes){
                        if (p.estaVivo()){
                            System.out.println(id + ". " + p.getNombre());
                            id++;
                        }
                    }
                    break;
                }
                case 11:{
                    System.out.println("--------------------\nGracias por jugar...\nSaliendio dek juego...\n-----");
                    break;
                }
                default:{
                    System.out.println("[ERROR]: Opcion no valida!");
                    break;
                }
            }
        } while (opc != 11);

        sc.close();
    }
}